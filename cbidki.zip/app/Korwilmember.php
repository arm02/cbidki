<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Korwilmember extends Model
{
    //
}
